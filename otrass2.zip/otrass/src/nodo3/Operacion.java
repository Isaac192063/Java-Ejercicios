/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodo3;

/**
 *
 * @author ASUS
 */
public class Operacion {
  private Nodo cabecera;

  public Operacion() {
  cabecera= null;
  }
  
  public void add(String cad){
    Nodo actual = new Nodo();
    actual.setCad(cad);
    actual.setNext(null);
    if(cabecera == null){
      cabecera = actual;
    }else{
      actual.setNext(cabecera);
      cabecera = actual;
    }
  }
  
  public void addFinal(String cad){
    Nodo actual = new Nodo();
    actual.setCad(cad);
    actual.setNext(null);
    if(cabecera == null){
      cabecera = actual;
    }else{
      Nodo hel = cabecera;
      while(hel.getNext() != null){
        hel = hel.getNext();
      }
      hel.setNext(actual);
    }
    
    
    
    
  }
  public void ver(){
    Nodo temporal = cabecera;
    
    while (temporal != null){
      System.out.println(temporal.getCad());
      temporal = temporal.getNext();
    }
    
  }
  
}
