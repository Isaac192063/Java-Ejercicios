/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodo3;

/**
 *
 * @author ASUS
 */
public class Nodo {
  private Nodo next;
  private String cad;

  public Nodo getNext() {
    return next;
  }

  public void setNext(Nodo next) {
    this.next = next;
  }

  public String getCad() {
    return cad;
  }

  public void setCad(String cad) {
    this.cad = cad;
  }
  
  
}
