/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodos;

import javax.swing.JOptionPane;

/**
 *
 * @author SCIS
 */
public class Gestion {

    Valores inicio;

    public Gestion() {
        this.inicio = null;
    }

    public void insertarInicio(String valor) {

        Valores nuevo = new Valores();
        nuevo.setValor(valor);
        nuevo.setEnlace(null);

//        if (this.inicio == null) {
//            this.inicio = nuevo;
//        } else {
//            nuevo.setEnlace(inicio);
//            this.inicio = nuevo;
//        }
        if (this.inicio == null) {
            this.inicio = nuevo;
        } else {
            nuevo.setEnlace(inicio);
            this.inicio = nuevo;
        }
    }
 
public void imprimir(){
     Valores temporal = inicio;
    while(temporal!= null){
        System.out.println(temporal.getValor());
        temporal = temporal.getEnlace();
    }
}
   
    
}
