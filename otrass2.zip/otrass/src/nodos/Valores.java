/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nodos;

/**
 *
 * @author SCIS
 */
public class Valores {
    private String valor;
    private Valores enlace;
    /**
     * @return the valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * @param valor the valor to set
     */
    public void setValor(String valor) {
        this.valor = valor;
    }

    public Valores getEnlace() {
        return enlace;
    }

    public void setEnlace(Valores valores) {
        this.enlace = valores;
    }
    
     
    
}
